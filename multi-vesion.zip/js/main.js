$(document).ready(function()
{
  $("#myModal2").modal();
    var swiper = new Swiper('.swiper-container1', {
      slidesPerView: 1,
      loop: true,
      loopFillGroupWithBlank: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  var swiper = new Swiper('.swiper-container2', {
      slidesPerView: 1,
      loop: true,
      loopFillGroupWithBlank: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.next-work',
        prevEl: '.prev-work',
      },
    });
  var swiper3 = new Swiper('.swiper-container3', {
      slidesPerView: 3,
      spaceBetween: 30,
      cssWidthAndHeight: true,
      loop: true,
      visibilityFullFit: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        768: {
          slidesPerView: 1,
          spaceBetween: 0,
        },
        425: {
          slidesPerView: 1,
          spaceBetween: 0,
        }
      },
    });
   $(".ServiseHI").slice(0, 0).show();
    $(".loadMore").on('click', function (e) {
        e.preventDefault();
        setTimeout(function() {
          $('.loader').show();
            $('.loader').delay(1000).fadeOut(50);
          });
        $(".ServiseHI:hidden").slice(0, 1).delay(1000).fadeIn(1000);
         if ($(".ServiseHI:hidden").length == 1) {
          $("#load").delay(1000).fadeOut(50);
              $("#MoreB").delay(1000).fadeOut(50).hide();  //ADD THIS
            }
    });
});
$(window).scroll(function () {
    if ($(this).scrollTop() > 50) {
        $('.totop a').fadeIn();
    } else {
        $('.totop a').fadeOut();
    }
});
window.onscroll=function(){myFunction()};
 var navbar=document.getElementById("topNav");
 var sticky=navbar.offsetTop;
 function myFunction()
 {
    if(window.pageYOffset>=sticky)
    {
        navbar.classList.add("sticky")
    }else
    {
        navbar.classList.remove("sticky");
    }
};

