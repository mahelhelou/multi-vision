<!DOCTYPE html>
<html dir="rtl">

<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <title>ملتي فيجن لخدمات التسويق الرقمي</title>
  <meta name="description" content="ملتي فيجن لخدمات التسويق الرقمي">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <?php wp_head(); ?>
</head>

<body id="home">

  <header>
    <p class="totop scroll">
      <a href="#home"><span class="fa fa-chevron-up"></span></a>
    </p>
    <div style="height: 50px;"></div>
    <div id="topNav" class="container">
      <div class="row">

        <!--Logo-->
        <div class="logo  text-center  col-md-2 col-sm-12  col-lg-2 col-sm-2">
          <div class="logoBox">
            <a href="<?php echo site_url(); ?>"><img
                src="<?php echo get_template_directory_uri() . '/images/logo.png' ?>"
                class="img-responsive center-block"></a>
          </div>
        </div>
        <!---Logo-->

        <nav class="navbar navbar-default navbar-static-top col-md-10 col-lg-10  col-sm-10 ">
          <div class="navbar-header ">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
              aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav" style="font-weight: bold;">
              <li class=""><a href="#">الرئيسية</a></li>
              <li class="scroll"><a href="#about">من نحن</a></li>
              <li class="scroll"><a href="#how-we-work">كيف نعمل</a></li>
              <li class="scroll"><a href="#services">خدماتنا</a></li>
              <li class="scroll"><a href="#team">فريق العمل</a></li>
              <li class="scroll"><a href="#occasions">مناسباتنا</a></li>
              <li class="scroll"><a href="#contact">اتصل بنا</a></li>
            </ul>
            <div class="btn button">
              <a style="font-weight: bold;" href="http://rosomat.net/public/profile/17022020.04.1669731777.pdf"
                target="_blank">
                بروفايل الشركة
              </a>
            </div>

          </div>
        </nav>

      </div>
    </div>
  </header>
  <div class="app-content content container-fluid">
    <div class="content-wrapper">
      <div class="">

      </div>
    </div>
  </div>

  <script type="text/javascript">
  window.setTimeout(function() {
    jQuery("#alertmassges").fadeTo(500, 0).slideUp(500, function() {
      jQuery(this).remove();
    });
  }, 4000);
  </script>
  <script type="text/javascript">
  window.setTimeout(function() {
    jQuery("#successfully_send_reservation").fadeTo(500, 0).slideUp(500, function() {
      jQuery(this).remove();
    });
  }, 2000);
  </script>
  <script type="text/javascript">
  window.setTimeout(function() {
    jQuery("#error_send_reservation").fadeTo(500, 0).slideUp(500, function() {
      jQuery(this).remove();
    });
  }, 2000);
  </script>

  <section>
    <div id="carousel-example-generic" class="carousel carousel-fade">
      <div class="carousel-inner" role="listbox">
        <div class="item slide1 active">
          <div class="container">
            <div class="row">
              <div class="col-md-6  text-center sliderText">
                <div class="bigTitle">
                  <div class="text-center">
                    <h1 class="ykaia animated zoomIn delay-1 ">حكايتنا</h1>
                  </div>
                </div>
                <!--bigTitle-->
                <div class="btn button btnSlider animated zoomIn delay-1" data-toggle="modal" data-target="#myModal">
                  ابدأ معنا
                </div>

              </div>
              <!--sliderText-->
              <div class="col-md-6">

                <img src="<?php echo get_template_directory_uri() . '/images/hekaya.png'; ?>" class="img-responsive animated zoomInLeft center-block">
              </div>
            </div>
          </div>
        </div>
        <div class="item slide1">

          <div class="container">
            <div class="row">
              <div class="col-md-6  text-center sliderText">
                <div class="bigTitle">
                  <div class="text-center">
                    <h1 class="ykaia animated zoomIn delay-1 ">إنجازاتنا</h1>
                  </div>
                </div>
                <!--bigTitle-->
                <div class="btn button btnSlider animated zoomIn delay-1" data-toggle="modal" data-target="#myModal">
                  ابدأ معنا
                </div>
                <!--button-->
              </div>
              <!--sliderText-->

              <div class="col-md-6">
                <img src="http://rosomat.net/public/img/rosomat_upload/slider/27102019.03.1720616271.png"
                  class="img-responsive animated zoomInLeft center-block">

              </div>

            </div>
            <!--row-->

          </div>

        </div>
        <!--item-->

        <!-- Item 2 -->

      </div>
      <!--item-->

      <!-- End Wrapper for slides-->

    </div>
    <!--inner-->

    </div>
    <!--carousel-->

  </section>

  <!-- about -->
  <section id="about" style="padding: 86px 0px 0px 0px;">

    <div class="container">

      <div class="row">

        <div class="bigTitle col-md-6 col-md-push-3" style="height: 89px;margin-top: 26px;">

          <div class="text-center">
            <h2 class="ykaia">من نحن</h2>
          </div>

        </div>
        <!--bigTitle-->

      </div>
      <!--row-->
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3 "></div>
          <div class="col-md-6 " style="text-align: center;">
            <span>شركة سعودية انطلقت من المدينة المنورة متخصصة في مجال تنظيم الفعاليات والمؤتمرات وتجهيز ملتقيات ومهرجانات محلية وعربية، كما تعمل في مجال البرمجيات والحلول التقنية. اعتمدت ملتي فيجن لتحقيق تميزها على فريق يمتلك الخبرات والكفاءات الادارية والفنية من خلال الالتزام بأرقى مستويات الجودة من أفكار خارج الصندوق وتطورت لتشمل الخدمات البرمجية والتقنية.</span>
          </div>
          <div class="col-md-3 "></div>
        </div>
      </div>
    </div>
    <!--container-->

  </section><!-- /about -->

  <section id="how-we-work" style="padding: 86px 0px 0px 0px;">

    <div class="container">

      <div class="row">

        <div class="bigTitle col-md-6 col-md-push-3" style="height: 89px;margin-top: 26px;">

          <div class="text-center">
            <h2 class="ykaia">كيف نعمل</h2>
          </div>

        </div>
        <!--bigTitle-->



      </div>
      <!--row-->
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3 "></div>
          <div class="col-md-6 " style="text-align: center;">
            <span>نمتلك في ملتي فيجن مجموعة من المبدعين أصحاب الخبرة والكفاءة حيث نعمل على تطوير فريق عملنا بشكل
              دائـم ليواكب أحدث التقـنيات الـــــمستــــخدمة</span>
          </div>
          <div class="col-md-3 "></div>
        </div>
      </div>
    </div>
    <!--container-->

  </section>
  <section style="padding: 0px 0px 0px 0px;">

    <div class="swiper-container swiper-container5">

      <div class="swiper-wrapper">

        <div class="container">
          <div class="row">
            <div class="col-sm-12">




              <div style="margin-top: 1%;" class="row carousel slide" data-ride="carousel">

                <!-- Wrapper for slides -->


                <li class="col-md-3 text-center wow animated zoomIn delay-2">
                  <h4 style="padding-bottom: 15px;;font-weight: bold;">نسمعك</h4>
                  <div class="Iconmoon "><img class="img-responsive center-block" src="<?php echo get_template_directory_uri() . '/images/we-write.png'; ?>">
                  </div>
                  <p style="font-size:15px;">نحول الأفكار المميزة إلى كلمات مقروءة، ثم نعيد صياغتها لتصل بأبسط الكلمات
                    وأكثرها تناسبًا مع مفاهيم الجمهور الذي تستــهدفــــه. </p>
                </li>
                <li class="col-md-3 text-center wow animated zoomIn delay-2">
                  <h4 style="padding-bottom: 15px;;font-weight: bold;">نحلل</h4>
                  <div class="Iconmoon "><img class="img-responsive center-block" src="<?php echo get_template_directory_uri() . '/images/we-search.png'; ?>">
                  </div>
                  <p style="font-size:15px;">نستخدم أحدث التقنيات لرصد التفاصيـل المحـيطة بمحتوى منصات التواصل الاجتماعي
                    وحملاتك الإعلانية، ونُخضعها للقراءة و التحليل. </p>
                </li>
                <li class="col-md-3 text-center wow animated zoomIn delay-2">
                  <h4 style="padding-bottom: 15px;;font-weight: bold;">نخطط</h4>
                  <div class="Iconmoon "><img class="img-responsive center-block" src="<?php echo get_template_directory_uri() . '/images/we-speak.png'; ?>">
                  </div>
                  <p style="font-size:15px;">نُكوِّن حملات إعلانية متكاملة وشاملة لكل أهدافك مستغليـن خبراتـنا المتخصصة
                    بالتسويق الإلكتروني لمُختلف منصات التواصل الاجتماعي. </p>
                </li>
                <li class="col-md-3 text-center wow animated zoomIn delay-2">
                  <h4 style="padding-bottom: 15px;;font-weight: bold;">ننفذ</h4>
                  <div class="Iconmoon "><img class="img-responsive center-block" src="<?php echo get_template_directory_uri() . '/images/we-draw.png'; ?>">
                  </div>
                  <p style="font-size:15px;">نشكّل كل المحتوى الخاص بك في مجموعة من التصامـــيــم والرســــوم القادرة
                    على جذب الانتباه وإيصال المعلومة بالصــــورة الأفـــضـــــل. </p>
                </li>
              </div><!-- /#myCarousel -->
            </div><!-- /.col-sm-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->


        <!--Slider-->

      </div>

      <!-- Add Arrows -->

    </div>
  </section><!-- /how-we-work -->

  <section id="services" style="padding: 0px 0px;">
  <div class="container">
    <div class="row">
      <div class="bigTitle col-md-6 col-md-push-3" style="height: 89px;margin-top: 26px;">
        <div class="text-center">
          <h2 class="ykaia">خدماتنا</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="col-md-3 "></div>
        <div class="col-md-6 " style="text-align: center;">
          <span>إنجازنا في ملتي فيجن طويل وخبرتنا بهذا الانجاز يزداد ، عندما تريد إنشاء مشروع ستحتاج لفريق يقدم لك
            الخدمة
            و النُّصح والإرشاد وخبراته المتراكمة</span>
        </div>
        <div class="col-md-3 "></div>
      </div>
    </div>
    <div style="clear: both;"></div>
    <div class="ServiseBox">
      <div class="row">
        <div class="col-lg-12 col-md-12">
        </div>
        <div id="portfolio" class="row" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s;">

          <!-- conferences -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/conference.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">تنظيم المعارض والمؤتمرات</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">لدينا فريق من الخبراء المدربين على أعلى مستوى وافضل قواعد المهارة والدقة
                      لتنفيذ الفعاليات والمؤتمرات بدءا من التخطيط والتنظيم والابداع في التنفيذ</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- المواقع الإلكترونية -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/website-design.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">المواقع الإلكترونية</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">لدينا فريق متكامل من الخبراء المختصين ذوي الكفاءة وبمجرد أن نبدأ في إنشاء
                      موقعك ستصل لمن تُريد للتعريف بنشاط ـــك التجاري ولتحقـــيــــق أفضل النتائــج والانطباع في الســوق
                      المحلي الــســعــودي والعالـــمـــــي</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- تصميم الموبايل -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/mobile-design.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">تطوير تطبيقات الجوال</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">لدينا فريق من المبرمجين يمتلك الخبرة الكافية من أجل تحويل الفكرة الى واقع
                      عبر تطوير تطبيق احترافي يسهل الترويج لمشـــروعــــك وأعــمــالــك ويــلبـــــي احـــتيـــاجات
                      المستخدمين ويشكل حلقـة وصـــل بيــنك وبــين عمـــلائك</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- متاجر الكترونية -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/ecommerce-design.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">المتاجر الالكترونية</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">نبدع بإنشاء وتصميم متاجر الكترونية احترافية ومميزة وتتناسب مع أنظمة التجارة
                      الالكترونية من خلال فريقنا ليلبي رغبات واحتياجات المستهلكين البــــاحثين عـــــن
                      المنـــــتجـــــات والخدمــات عبر الانــــتـــــرنــــــت</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- تصميم الجرافيك -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/graphic-design.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">تصميم الجرافيك</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">لدينا فريق متكامل من الخبراء المختصين ذوي الكفاءات العالية مع استخدام أفضل
                      الأدوات والأفـــــكار الإبداعية للخروج بتصميم جذاب يتناســــــــــب مع أذواق الجمهور المستهدف</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- تسويق الكتروني -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/emarketing.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">التسويق الإلكتروني</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">صناعة المحتوى التسويقي المتناسب مع خدمات ومنتجات وتوجهات الشركة نعمل على
                      التسويق الرقمي الذي يبدأ من مواقع التواصل الاجتماعي مروراً بمحركات البحث، لضم ــــان تفاعل الجمهور
                      من خلال تلك المواقـــع</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>

          <!-- توظيف عن بعد -->
          <div class="col-md-6 col-lg-4 col-xs-12 mix social wow animated zoomIn delay-2" data-wow-delay="0.3s"
            style="text-align: right; display: inline-block;" data-bound="">
            <div class="service-box hvr-bounce-in">
              <div style="text-align: center;">
                <i class="fa "><img class=""
                    src="<?php echo get_template_directory_uri() . '/images/remote-work.png'; ?>"></i>
              </div>
              <div style="text-align: center;">
                <h4><a style="font-size: 20px;color: #c31313;font-weight: bold;">التوظيف عن بعد</a></h4>
                <div class="col-md-12" id="aerrr" style="text-align: justify;line-height:20px;direction: rtl">
                  <h6>
                    <p style="height: 130px">لدينا فريق كامل متكامل يعمل على تلبية احتياجاتك واحتياجات الشركات ورواد
                      الاعمال باقل التكاليف واعلى جودة في شتى المجالات ومختلف أوساط العمل</p>
                  </h6>
                </div>
              </div>
            </div>
          </div>



        </div>
      </div>
    </div>
  </div>
  <div style="clear: both;"></div>

  <section style="padding: 5px 0px;">
    <div class="container">
      <div class="row">
        <div class="bigTitle col-md-6 col-md-push-3" style="height: 89px;margin-top: 26px;">
          <div class="text-center">
            <h2 class="ykaia">فريق العمل</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3 "></div>
          <div class="col-md-6 " style="text-align: center;">
            <span>فريق عمل مؤهلين ومدربين وفق أفضل قواعد المهارة والدقة لتنفيذ المشاريع البرمجية والفعاليات والمؤتمرات
              بدءا من التخطيط والتنظيم والابداع في التنفيذ.</span>
          </div>
          <div class="col-md-3 "></div>

        </div>
      </div>
    </div>
  </section>

  <div style="clear: both;"></div>

  <section id="team"
    style="background: url(<?php echo get_template_directory_uri() . '/images/team-bg.png'; ?>);background-size: contain;background-repeat: no-repeat;padding: 5px 0px;">

    <div class="container">
      <div class=" col-md-12">
        <div class="swiper-container swiper-container3">
          <div class="swiper-wrapper">
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class="">
                <span class="topQuote text-right"></span>

                <img src="<?php echo get_template_directory_uri() . '/images/team-yasser.png'; ?>"
                  class="img-responsive center-block">
                <h4 style="font-weight: bold;">أ.ياسر العتيق</h4>
                <small>مدير التنفيذي لمؤسسة سر العطر</small>
                <p class="text-justify">كان لي تجرية مع اكثر من شركة في التسويق وإدارة مواقع التواصل الاجتماعي،
                  وملتي فيجن هي افضل شركة تعاملت معها</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class="">
                <span class="topQuote text-right"></span>

                <img src="<?php echo get_template_directory_uri() . '/images/team-yasser.png'; ?>"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">أ.ابراهيم محمد الخريجي</h4>

                <small>المدير التنفيذي لمصنع الخريجي للعطورات - السعودية</small>

                <p class="text-justify">في احيان كثيرة يعجز اللسان عن التعبير ، فيصبح القلم ابلغ وسيلة لما تحوية
                  النفوس فهذا قلمي لكم ان برى ليخط لشخصك الكريم أعمق حروف الشكر والتقدير على مالمستة من حرص ورقي في
                  التعامل فمزيدا من التقدم ومزيدا من النجاح.</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/22102019.11.205535088.png"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">فيصل الخالدي</h4>

                <small>مؤسس متجر سمارت سبيس</small>
                ملتي فيجن رواد الإبداع والنجاح بامتياز، أبطال في خلق المحتوى الابداعي وتصاميم
                اتمنى لهم كل النجاح</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/22102019.11.1812527348.png"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">أ.عادل الحربي</h4>

                <small>مؤسس سمكمك للبحريات</small>

                <p class="text-justify">بالنسبه لخدمتكم بكل صراحه جدا جميله شي فوق المتوقع خصوصا تعامل فريق العمل
                  واحساسهم بالمسئوليه على الحساب من ناحية التصاميم المنوعه وتنشيط الحساب وزيادة التفاعل وكذلك خدمة
                  العملاء الرد على الزبائن فوري وبكل مرونه ١٠٠% وكانت البداية تجربه لمدة شهرين لكن جهودكم جبارة
                  والأفكار المتجددة ورقي التعامل وتعاملكم اخويي ، التعامل معكم مستمر بإذن الله تعالى</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/17092019.10.1561681167.png"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">أ.محمد العلي</h4>

                <small>مدير مكتب شركة ميدياغيث -السعودية</small>

                <p class="text-justify">نشكر شركة ملتي فيجن الرقمية على عملها المميز والمبدع في مجال التصميم الجرافيك
                  والاعلانات الرقمية الخاصة بشركة ميديا قيت ونفخر بالعمل معهم ونتمنى لهم مزيد من التفوق والنجاح.</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/22102019.11.2497826581.png"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">م.عبدالله مسعود</h4>

                <small>شركة تأشيرتي للسياحة والسفر</small>

                <p class="text-justify">التعاون مع شركة ملتي فيجن اختصر علينا الطريق للوصول للعملاء وذلك عبر تصاميمهم
                  الابداعية، واكثر ما يميزهم سرعة التواصل والمرونة العالية، فخور بشراكة تأشيرتي مع ملتي فيجن،
                  وبالتوفيق
                  وإلى الإمام دائمًا</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/22102019.06.0130025218.jpeg"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">ركاد العنزي</h4>

                <small>مؤسس بين السنعات</small>

                <p class="text-justify">ملتي فيجن شركة تجمع عدد من المبدعين لصناعة وعمل المحتوى الجيد في السوشال ميديا
                  لموقعك أو متجرك الإلكتروني، وأنصح بالتعامل معهم لمن يرغب في جعل موقعه أكثر متابعة وإثارة للمتابعين
                </p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/22102019.06.1372260632.jpeg"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">ناصر العنزي</h4>

                <small>مدير نادي Delta Fitness</small>

                <p class="text-justify">شهادة حق لهذا الكيان العظيم ملتي فيجن لجميع ماتقدموه لعملائكم من سرعة في
                  الاداء
                  وتقديم الدعم في عالم التسويق ونحن في نادي دلتا فيتنس لرياضة السيدات سعدنا بالعمل معكم ونتطلع دائما
                  ان نكون شركاء في هذا النجاح</p>
              </div>
            </div>
            <div class="swiper-slide text-center wow animated zoomIn delay-2">
              <div class=" ">
                <span class="topQuote text-right"></span>

                <img src="http://rosomat.net/public/img/rosomat_upload/saidaboutus/11112019.05.0677571465.PNG"
                  class="img-responsive center-block">


                <h4 style="font-weight: bold;">خالد ‫آل الصقري</h4>

                <small>مؤسس شركة قبب</small>

                <p class="text-justify">الشكر لكم أنت القائمين على العمل الاكثر من رائع 🧡🧡🧡 وجدا فخور بالعمل معكم
                  يا فريق ملتي فيجن 🤝🔥 وعملت مع فريق ملتي فيجن الفريق الأكثر من رائع ، سمحين وطيبين ويفهمونك ويفهمون
                  طلباتك ، وينفذونها لك أفضل مما تتطلب ، العمل معهم بيتكرر 🧡.</p>
              </div>
            </div>

            <!--Slider-->

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
          <!-- Add Arrows -->

        </div>
      </div>

    </div>

  </section>

  <!-- occasions -->
  <section id="occasions">
    <div class="container">
      <div class="row">
        <div class="bigTitle col-md-6 col-md-push-3" style="height: 89px;margin-top: 26px;">
          <div class="text-center">
            <h2 class="ykaia">مناسباتنا</h2>
          </div>


        </div>
        <!--bigTitle-->

      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3 "></div>
          <div class="col-md-6 " style="text-align: center;">
            <span>نحن نعطي مساحة كبيرة للفريق للإستمتاع بإنجازاته من خلال التشبيك الميداني وإقامة الحفلات والمناسبات
              التي تدخل السرور على قلوبنا.</span>
          </div>
          <div class="col-md-3 "></div>

        </div>
      </div>
      <div style="clear: both;"></div>

      <div id="Works" class="Our_work" style="padding: 0px 0px;">


        <div class="container">

          <div class="row">


            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/18022020.04.2373511198.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>متجر تاله</h4>
                  </a>
                  <a href="https://talahdates.com.au"><span class="workIcon"><i class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/75/متجر_تاله" target="_blank"><span class="workIcon"><i
                        class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/18022020.02.3862442359.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>موقع رابطة الاعمال السعودية</h4>
                  </a>
                  <a href="http://asbn.org.au"><span class="workIcon"><i class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/74/موقع_رابطة_الاعمال_السعودية" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/18022020.02.3568107882.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>شركة يوفي - استراليا</h4>
                  </a>
                  <a href="https://yof.com.au"><span class="workIcon"><i class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/73/شركة_يوفي_-_استراليا" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/28102019.03.5398893831.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>تصميم موقع تاج الأعمال</h4>
                  </a>
                  <a href="https://www.behance.net/gallery/76158929/_"><span class="workIcon"><i
                        class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/63/تصميم_موقع_تاج_الأعمال" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/28102019.01.0496598281.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>تصميم موقع قناة السلام الفضائية</h4>
                  </a>
                  <a href="https://www.behance.net/gallery/41865667/Salam-TV-Website"><span class="workIcon"><i
                        class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/59/تصميم_موقع_قناة_السلام_الفضائية" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/27102019.04.1415624363.jpg"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>تصميم موقع عرب بروت</h4>
                  </a>
                  <a href="https://www.behance.net/gallery/60691997/_"><span class="workIcon"><i
                        class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/49/تصميم_موقع_عرب_بروت" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/24102019.01.5662664438.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>تصميم موقع الجذلاني للمحاماة</h4>
                  </a>
                  <a href="https://www.behance.net/gallery/83546167/_"><span class="workIcon"><i
                        class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/33/تصميم_موقع_الجذلاني_للمحاماة" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/24102019.12.3726073505.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>موقع بيت السنعات</h4>
                  </a>
                  <a href="https://www.behance.net/gallery/83546133/_"><span class="workIcon"><i
                        class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/26/موقع_بيت_السنعات" target="_blank"><span class="workIcon"><i
                        class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>
            <div class="col-md-4 wow animated zoomIn delay-2">
              <div class="ourwork-img"><img
                  src="http://rosomat.net/public/img/rosomat_upload/projects/24102019.12.3153708587.png"
                  class="img-responsive">
                <div class="workHover">
                  <a>
                    <h4>تصميم موقع مملكة العسل</h4>
                  </a>
                  <a href="https://mkasal.com"><span class="workIcon"><i class="fas fa-link"></i></span></a>
                  <a href="http://rosomat.net/work/view/25/تصميم_موقع_مملكة_العسل" target="_blank"><span
                      class="workIcon"><i class="fas fa-eye"></i></span></a>
                </div>
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>
    <div id="MoreB" class="text-center">
      <div class="loader"></div>
    </div>
  </section>
  </div>
</section>

  <!--<section id="About" style="margin-top: 4%;background: url(http://rosomat.net/public/site_layout/img/back-2.png);padding-bottom: 14%;background-size: 125%;
">

  <div class="container" style="margin-top: 4%;">

    <div class="row">
<div class="container">
  <div class="row">
  </div>
    <div class="row text-center">
          <div class="col-md-3 wow animated zoomIn delay-2">
          <div class="counter">
      <i class="fa"><img src="http://rosomat.net/public/img/rosomat_upload/setting/27122019.02.5471772284.png" style="width: 100px;height: 100px"></i>
      <h2 class="timer count-title count-number" data-to="100" data-speed="1500"></h2>
       <h4 style="font-family: cursive;">1600 كأساً</h4>
       <h3>نقهويكم شهريا</h3>
    </div>
          </div>
              <div class="col-md-3 wow animated zoomIn delay-2">
               <div class="counter">
      <i class="fa"><img src="http://rosomat.net/public/img/rosomat_upload/setting/28122019.10.5150256071.png" style="width: 100px;height: 100px"></i>
      <h2 class="timer count-title count-number" data-to="1700" data-speed="1500"></h2>
       <h4 style="font-family: cursive;">24 موظف</h4>
       <h3>توظيف</h3>
    </div>
              </div>
              <div class="col-md-3 wow animated zoomIn delay-2">
                  <div class="counter">
      <i class="fa"><img src="http://rosomat.net/public/img/rosomat_upload/setting/27122019.02.5344180396.png" style="width: 100px;height: 100px"></i>
      <h2 class="timer count-title count-number" data-to="11900" data-speed="1500"></h2>
       <h4 style="font-family: cursive;">10000</h4>
       <h3>انجازاتنا</h3>
    </div></div>
              <div class="col-md-3 wow animated zoomIn delay-2">
              <div class="counter">
      <i class="fa"><img src="http://rosomat.net/public/img/rosomat_upload/setting/27122019.02.5340215027.png" style="width: 100px;height: 100px"></i>
      <h2 class="timer count-title count-number" data-to="157" data-speed="1500"></h2>
       <h4 style="font-family: cursive;">90</h4>
       <h3>لعبتنا التسويق</h3>
    </div>
              </div>
         </div>
</div>



    </div>

</div>

</section>-->



  <!--End video-->

  <!--Start Servise-->



  <!--End Servise-->



  <!--Start What Say-->


  <!--End What Say-->

  <!--Start Our Work-->


  <!--End Our Work-->

  <!--Start Customer-->




  <!-- <section style="padding: 0px 0px;">

    <div class="container">

      <div class="row">

        <div class="bigTitle col-md-6 col-md-push-3" style="height: 66px;margin-top: 26px;">

          <div class="text-center">
            <h2 class="ykaia">عملائنا</h2>
          </div>

        </div>
        <!~~bigTitle~~>

      </div>
      <!~~row~~>

    </div>
    <!~~conatiner~~>
    <br />
    <div class="container" id="Customer">

      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3 "></div>
          <div class="col-md-6 " style="text-align: center;">
            <span>
              تفخر شركة <span class="redR"> ملتي فيجن </span>
              بأنها من خلال فترة عمله الطويلة قد كسبت شريحة واسعة من العملاء في الوطن العربي خصيصاً في المملكة العربية
              السعودية و تجاوزنا الحدود لنصل إلى استراليا مبرهنين بذلك على موثوقية أنظمة الشركة وكفائة عملها و في عدة
              لغات ومن أهم العملاء:
            </span>
          </div>
          <div class="col-md-3 "></div>

        </div>
      </div>
      <div class="row marginTop text-center">




        <div class="marginTop text-center CustomerBox">



          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://masafksa.com/"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/08072020.02.3574206182.png" alt="مطعم مسف"
                  alt="مطعم مسف"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://rabealfla.com"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/15062020.11.4099603642.png"
                  alt="ربيع الفلا للذبائح واللحوم طازجة" alt="ربيع الفلا للذبائح واللحوم طازجة"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://www.instagram.com/hanethmarkh/"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/14062020.06.5581263297.jpg" alt="حنيذ مرخ"
                  alt="حنيذ مرخ"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://www.instagram.com/makmotksa/"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/07052020.03.1752452664.png"
                  alt="مطاعم مكموت" alt="مطاعم مكموت"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://www.instagram.com/rymaz_sweets/"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/04052020.06.1534355306.png"
                  alt="حلويات ريماز" alt="حلويات ريماز"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://twitter.com/Restwaterksa"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/01042020.06.3459443336.png"
                  alt="مياه رست | Rest Water" alt="مياه رست | Rest Water"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://twitter.com/oyounzaina"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/01042020.06.3218496924.png" alt="عيون زينة"
                  alt="عيون زينة"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="http://rosomat.net"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/03022020.03.2436521725.png" alt="شركة ماتس"
                  alt="شركة ماتس"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="http://rosomat.net"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/03022020.03.194715919.png"
                  alt="ديوانية الخيمة" alt="ديوانية الخيمة"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="http://asbn.org.au"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/03022020.03.1740226701.png"
                  alt="رابطة الاعمال" alt="رابطة الاعمال"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://twitter.com/CapriOud"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/10122019.03.4091423001.png"
                  alt="كابري للعود" alt="كابري للعود"></a>

            </div>
            <!~~customerLogo~~>

          </div>
          <div class=" col-lg-3 col-md-2 col-sm-6 col-sx-6 wow animated zoomIn delay-2">

            <div class="customerLogo">

              <a href="https://twitter.com/gobabSA"> <img class="img-responsive center-block"
                  src="http://rosomat.net/public/img/rosomat_upload/customer/07112019.04.0222151382.png" alt="مشروع قبب"
                  alt="مشروع قبب"></a>

            </div>
            <!~~customerLogo~~>

          </div>






        </div>

      </div>
      <!~~row~~>




    </div>
    <!~~container~~>
    <div id="MoreB" class="text-center">

      <div class="loader"></div>


      <div class="btn button  marginTop">

        <a href="http://rosomat.net/customer" target="_blank">

          <span class="moreIcon"><i class="fas fa-arrow-down"></i></span><span class="moreText">هناك المزيد</span></a>

      </div>

    </div>
  </section> -->

  <!--End Customer-->

  <!--Start Bloger-->



  <!-- Card Flip -->
  <div class="col-lg-4 col-md-6 col-xs-12  Web wow animated zoomIn delay-2" style="">
    <div class="pricing-table-item ">
      <!-- <div class="pricing-table-item table-active"> -->

      <div class="plan-price">
        <div class="price-value"><img
            src="http://rosomat.net/public/img/rosomat_upload/infographic/10112019.11.1069689636.png"
            style="width: 338px;height:386px;"></div>

      </div>

      <div class="plan-list">

      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6 col-xs-12  Web wow animated zoomIn delay-2" style="">
    <div class="pricing-table-item ">
      <!-- <div class="pricing-table-item table-active"> -->

      <div class="plan-price">
        <div class="price-value"><img
            src="http://rosomat.net/public/img/rosomat_upload/infographic/10112019.10.359631322.png"
            style="width: 338px;height:386px;"></div>

      </div>

      <div class="plan-list">

      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6 col-xs-12  Web wow animated zoomIn delay-2" style="">
    <div class="pricing-table-item ">
      <!-- <div class="pricing-table-item table-active"> -->

      <div class="plan-price">
        <div class="price-value"><img
            src="http://rosomat.net/public/img/rosomat_upload/infographic/09112019.04.2572371997.png"
            style="width: 338px;height:386px;"></div>

      </div>

      <div class="plan-list">

      </div>
    </div>
  </div>
  <!-- End Card Flip -->

  </div>
  </div>
  <div id="MoreB" class="text-center">

    <div class="loader"></div>


    <div class="btn button  marginTop">

      <a href="http://rosomat.net/infographic" target="_blank">

        <span class="moreIcon"><i class="fas fa-arrow-down"></i></span><span class="moreText">هناك المزيد</span></a>

    </div>

  </div>
  </div>

  </section>

  </div>
  </section>

  <footer id="contact">

    <div class="container">

      <div class="row">



        <div class="col-md-12 col-sm-12 col-sx-12">

          <div class="footerLogo" style="margin-top: 35px;">
            <div class="col-md-4 col-sm-4 col-sx-4">

              <a href="<?php echo site_url(); ?>"><img src="<?php echo get_template_directory_uri() . '/images/logo.png'; ?>"
                  style="width: 23%;" class="img-responsive"></a>

              <h5>ملتي فيجن الرقمية</h5>
            </div>
            <div class="col-md-4 col-sm-4 col-sx-4">
              <div class="location">

                <div>

                  <span class="footerIcon" style=" padding: 4px 7px; "><i
                      class="fas fa-map-marker-alt footer-contacts-icon"></i></span>

                  <p><span>Jeddah - Saudi Arabia</span></p>

                </div>


                <div>

                  <span class="footerIcon"><i class="fab fa-whatsapp footer-contacts-icon"></i></span>

                  <p><span style="direction: ltr;"><a
                        href="https://api.whatsapp.com/send?phone=966553142444">00966553142444</a></span></p>

                </div>
                <div>

                  <span class="footerIcon"><i class="fas fa-phone footer-contacts-icon"></i></span>
                  <p><span style="direction: ltr;"><a>00966553142444 - 00966565500505</a></span></p>
                </div>
                <div>

                  <span class="footerIcon"><i class="fa fa-envelope footer-contacts-icon "></i> </span>

                  <p><span>info@multivison.sa</span></p>

                </div>

              </div>
            </div>

            <div class="col-md-4 col-sm-4 col-sx-4">
              <div id="myModal2-mail"
                style="text-align: center;margin-top: 23px;float: right;width: 78%;/* margin: auto; */position: relative;">
                <p style="font-size: 15px;">ملتي فيجن شركة فلسطينية مختصة في الإبداع الرقمي و هي علامة تجارية مسجلة
                  بوزارة
                  التجارة والاستثمار باسم مؤسسة زينة للدعاية و الإعلان</p>

              </div>
              <ul class="nav navbar-nav">

                <li style="padding-right: 9px;"><a class="nav-social center" href="https://www.facebook.com/rosomatcom">
                    <i class="topIcon fab fa-facebook-f"></i></a></li>

                <li style=""><a class="nav-social center" href="https://twitter.com/rosomatcom"> <i
                      class="topIcon fab fa-twitter"></i></a></li>

                <li style=""><a class="nav-social center" href="https://www.linkedin.com/company/rosomat"> <i
                      class="topIcon fab fa-linkedin-in"></i></a> </li>

                <li style=""><a class="nav-social center" href="https://www.instagram.com/rosomatcom"> <i
                      class="fab fa-instagram"></i></a> </li>

                <li style=""><a class="nav-social center"
                    href="https://www.youtube.com/channel/UCnJloahfHY6hVeTnGtHAkBQ"> <i class="fab fa-youtube"></i></a>
                </li>

                <li style=""><a class="nav-social center" href="https://www.behance.net/rosomat"> <i
                      class="fab fa-behance"></i></a> </li>

              </ul>

            </div>

          </div>
          <!--footoerLogo-->

        </div>
        <!--col-->

      </div>

    </div>
    <!--conatiner-->

  </footer>

  <!-- Modal -->

  <div id="myModal" class="modal fade" role="dialog">

    <div class="modal-dialog">



      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">املأ هذه البيانات وأنتظر تواصلنا معك</h4>

        </div>

        <div class="modal-body">



          <!-- ############ بدء كود صفحة الإرسال ############ -->

          <!-- تم إنشاء هذا النموذج آليا بواسطة برمجية صانع نماذج المراسلة من موقع-->

          <!-- www.lion4h.com -->

          <!-- بإمكانك حذف ما سبق -->

          <div id="success_requests"></div>
          <form method="post" class="form-horizontal">



            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="Fullname">اسمك الكامل</label>

                <div>

                  <input type="text" required class="form-control" id="name1">

                </div>

              </div>
              <!--form-group-->

            </div>

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="email">البريد</label>

                <div><input type="email" required class="form-control" id="email1"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="country">الدولة</label>

                <div><input type="text" required class="form-control" id="country1"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="city">المدينة</label>

                <div><input type="text" required class="form-control" id="city1"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="phone">رقم الهاتف</label>

                <div><input type="number" required class="form-control" id="phone1"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="services">نوع الخدمة</label>

                <div>



                  <select class="form-control" required id="services1">

                    <option value="" selected>يرجى الاختيار</option>
                    <option value="1">تصميم مواقع</option>
                    <option value="2">إدارة السوشيال ميديا</option>
                    <option value="3">تصميم شعارات</option>
                    <option value="4">الهوية البصرية</option>
                    <option value="5">تصميم وبرمجة التطبيقات</option>

                  </select>



                </div>

              </div>

            </div>
            <!--form-group-->

            <div class="form-group">

              <div class="col-sm-offset-1 col-sm-10">


                <button class="btn btn-warning btn-default submitt"><i
                    class="fas fa-location-arrow  Services-icon"></i><span>إرســـــال </span></button>
              </div>

            </div>

          </form>







        </div>

      </div>



    </div>

  </div>





  <div id="myModal" class="modal fade myModalpack" role="dialog">

    <div class="modal-dialog">



      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">املأ هذه البيانات وأنتظر تواصلنا معك</h4>

        </div>

        <div class="modal-body">



          <!-- ############ بدء كود صفحة الإرسال ############ -->

          <!-- تم إنشاء هذا النموذج آليا بواسطة برمجية صانع نماذج المراسلة من موقع-->

          <!-- www.lion4h.com -->

          <!-- بإمكانك حذف ما سبق -->

          <div id="success_requestspack"></div>
          <form method="post" class="form-horizontal">



            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="Fullname">اسمك الكامل</label>

                <div>

                  <input type="text" required class="form-control" id="name2">

                </div>

              </div>
              <!--form-group-->

            </div>

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="email">البريد</label>

                <div><input type="email" required class="form-control" id="email2"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="country">الدولة</label>

                <div><input type="text" required class="form-control" id="country2"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="city">المدينة</label>

                <div><input type="text" required class="form-control" id="city2"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label " for="phone">رقم الهاتف</label>

                <div><input type="number" required class="form-control" id="phone2"></div>

              </div>

            </div>
            <!--form-group-->

            <div class=" col-sm-6">

              <div class="form-group">

                <label class="control-label" for="services">نوع الخدمة</label>

                <div>



                  <select class="form-control" required id="services2">

                    <option value="" selected>يرجى الا الباقة</option>

                    <option value="1_pack">باقة مميزة</option>
                    <option value="2_pack">باقية ذهبية</option>
                    <option value="3_pack">باقة احترافية</option>

                  </select>



                </div>

              </div>

            </div>
            <!--form-group-->

            <div class="form-group">

              <div class="col-sm-offset-1 col-sm-10">


                <button class="btn btn-warning btn-default submitpack"><i
                    class="fas fa-location-arrow  Services-icon"></i><span>إرســـــال </span></button>
              </div>

            </div>

          </form>







        </div>

      </div>



    </div>

  </div>
  <a href="https://api.whatsapp.com/send?phone=966570371281" class="floatwhatsapp" target="_blank">
    <i class="fab fa-whatsapp my-floatwhatsapp"></i>
  </a>
  <div id="loader-wrapper">
    <div id="loader"></div>

    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>

  </div>

  <?php wp_footer(); ?>
</body>
</html>